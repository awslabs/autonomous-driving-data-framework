#  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License").
#    You may not use this file except in compliance with the License.
#    You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.


import json
import logging
import os
import random
import string
import textwrap
from datetime import timedelta
from typing import Iterator, List, TypeVar

import boto3
from boto3.dynamodb.conditions import Attr
from airflow import DAG, settings
from airflow.contrib.hooks.aws_hook import AwsHook
from airflow.exceptions import AirflowException
from airflow.models import Connection
from airflow.models.taskinstance import TaskInstance
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.operators.batch import AwsBatchOperator
from airflow.providers.amazon.aws.transfers.s3_to_redshift import S3ToRedshiftOperator
from airflow.utils.dates import days_ago
from boto3.session import Session
from mypy_boto3_batch.client import BatchClient

from poc2_batch_dags import batch_dag_config, batch_creation_and_tracking

ValueType = TypeVar("ValueType")

DAG_ID = os.path.basename(__file__).replace(".py", "")
PROVIDER = batch_dag_config.PROVIDER
TASK_DEF_XCOM_KEY = "job_definition_arn"

DEFAULT_ARGS = {
    "owner": "airflow",
    "depends_on_past": False,
    "email": ["airflow@example.com"],
}

logger = logging.getLogger("airflow")
logger.setLevel("DEBUG")


def try_create_aws_conn(**kwargs):
    conn_id = "aws_batch"
    try:
        AwsHook.get_connection(conn_id)
    except AirflowException:
        extra = json.dumps({"role_arn": batch_dag_config.DAG_ROLE}, indent=2)
        conn = Connection(conn_id=conn_id, conn_type="aws", host="", schema="", login="", extra=extra)
        try:
            session = settings.Session()
            session.add(conn)
            session.commit()
        finally:
            session.close()


def create_batch_of_drives(ti, **kwargs):
    """
    if Batch Id already exists, then skip
    List Drive Folders in S3
    For New Drives, List Segments
    Put them in Dynamo and Assign to a batch if not assigned already
    Add Drives until reaching max segments allowed in 1 batch (hard limit of 10k)
    """

    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(batch_dag_config.DYNAMODB_TABLE)
    batch_id = kwargs['dag_run'].run_id

    response = table.scan(
        Select='COUNT',
        FilterExpression=Attr('batch_id').eq(batch_id),
    )
    segments_in_batch = response['Count']
    if segments_in_batch > 0:
        print("Batch Id already exists in tracking table - using existing batch")
        return segments_in_batch

    print("New Batch Id - collecting unprocessed drives from S3 and adding to the batch")
    segments_in_batch = 0
    while True:
        print(f"Segments in Batch: {segments_in_batch}")
        segments_in_batch, next_continuation = batch_creation_and_tracking.add_drives_to_batch(
            table,
            batch_dag_config.SRC_BUCKET,
            batch_dag_config.MAX_NUM_SEGMENTS_PER_BATCH,
            batch_id,
            segments_in_batch=segments_in_batch,
            next_continuation=None if segments_in_batch == 0 else next_continuation,
            segment_suffix=batch_dag_config.SEGMENT_SUFFIX
        )
        if next_continuation is None or segments_in_batch > batch_dag_config.MAX_NUM_SEGMENTS_PER_BATCH:
            print(f"Final Batch Size = {segments_in_batch} segments")
            return segments_in_batch


def get_job_queue_name() -> str:
    """get_job_queue_name retrieves the the available JobQueues created
    based on the inputs of the batch-compute manifest file.
    """
    return batch_dag_config.JOB_CONFIGS[PROVIDER]["JOB_QUEUE_ARN"]


def get_job_name() -> str:
    v = "".join(random.choice(string.ascii_lowercase) for i in range(6))
    return f"addl-arriver-poc2-simplemock-job-{v}"


def get_job_def_name() -> str:
    v = "".join(random.choice(string.ascii_lowercase) for i in range(6))
    # return f"addl-{batch_dag_config.DEPLOYMENT_NAME}-{batch_dag_config.MODULE_NAME}-jobdef-{v}"
    #return f"addl-{batch_dag_config.DEPLOYMENT_NAME}-{batch_dag_config.MODULE_NAME}-simplemock-jobdef"
    return batch_dag_config.JOB_CONFIGS[PROVIDER]["JOB_DEF_NAME"]


def get_batch_client() -> BatchClient:
    sts_client = boto3.client("sts")

    response = sts_client.assume_role(
        RoleArn=batch_dag_config.DAG_ROLE,
        RoleSessionName="AssumeRoleSession1",
    )

    session = Session(
        aws_access_key_id=response["Credentials"]["AccessKeyId"],
        aws_secret_access_key=response["Credentials"]["SecretAccessKey"],
        aws_session_token=response["Credentials"]["SessionToken"],
    )
    return session.client("batch")


def register_job_definition_on_demand(ti, job_def_name: str) -> str:
    client = get_batch_client()
    region = batch_dag_config.REGION
    account = boto3.client('sts').get_caller_identity().get('Account')

    container_properties = {
        "image": f"{account}.dkr.ecr.{region}.amazonaws.com/{batch_dag_config.ECR_REPO_NAME}:latest",
        "jobRoleArn": batch_dag_config.DAG_ROLE,
        "environment": [
            {
                "name": "AWS_DEFAULT_REGION",
                "value": batch_dag_config.REGION,
            }
        ],
        "resourceRequirements": [
            {"value": batch_dag_config.VCPU, "type": "VCPU"},
            {"value": batch_dag_config.MEMORY, "type": "MEMORY"},
        ],
    }
    if PROVIDER == "FARGATE":
        container_properties["executionRoleArn"] = batch_dag_config.DAG_ROLE

    resp = client.register_job_definition(
        jobDefinitionName=job_def_name,
        type="container",
        containerProperties=container_properties,
        propagateTags=True,
        timeout={"attemptDurationSeconds": batch_dag_config.CONTAINER_TIMEOUT},
        platformCapabilities=[PROVIDER if PROVIDER in ["EC2", "FARGATE"] else "EC2"],
    )
    ti.xcom_push(key=TASK_DEF_XCOM_KEY, value=resp["jobDefinitionArn"])


def deregister_job_definition(ti, job_def_arn: str) -> None:
    client = get_batch_client()
    response = client.deregister_job_definition(jobDefinition=get_job_def_name())
    ti.xcom_push(key="TASK_DEF_DEREGISTER_XCOM_KEY", value=response["ResponseMetadata"])


with DAG(
    dag_id=DAG_ID,
    default_args=DEFAULT_ARGS,
    dagrun_timeout=timedelta(hours=2),
    start_date=days_ago(1),  # type: ignore
    schedule_interval="@once",
    render_template_as_native_obj=True
) as dag:

    total_simulations = 50
    parallelism = 10

    job_definition_name = get_job_def_name()
    job_name = get_job_name()
    queue_name = get_job_queue_name()

    create_aws_conn = PythonOperator(
        task_id="try_create_aws_conn",
        python_callable=try_create_aws_conn,
        dag=dag,
    )

    create_batch_of_drives_task = PythonOperator(
        task_id="create_batch_of_drives_task",
        python_callable=create_batch_of_drives,
        dag=dag,
        provide_context=True
    )

    register_batch_job_defintion = PythonOperator(
        task_id="register-batch-job-definition",
        dag=dag,
        provide_context=True,
        python_callable=register_job_definition_on_demand,
        op_kwargs={"job_def_name": job_definition_name},
    )

    def my_func(**kwargs):
        ti = kwargs['ti']
        ds = kwargs['ds']
        array_size = ti.xcom_pull(task_ids='create_batch_of_drives_task', key='return_value')
        batch_id = kwargs['dag_run'].run_id
        run_id = "{{run_id}}"

        if isinstance(array_size, dict):
            array_size = array_size['segments_in_batch']

        platformCapabilities = [PROVIDER if PROVIDER in ["EC2", "FARGATE"] else "EC2"],

        op = AwsBatchOperator(
            task_id="submit_batch_job_op",
            job_name=job_name,
            job_queue=queue_name,
            aws_conn_id="aws_batch",
            job_definition=get_job_def_name(),
            array_properties={
                'size': int(array_size)
            },
            overrides={
                "command": [
                    "bash",
                    "-c",
                    textwrap.dedent(
                        """\
                            #/usr/bin/env bash
                            echo "[$(date)] Starting $JOB_NAME for batch $BATCH_ID and index: $AWS_BATCH_JOB_ARRAY_INDEX"
    
                            echo "Getting file from Dynamo for batch $BATCH_ID and index: $AWS_BATCH_JOB_ARRAY_INDEX"
                            
                            python simulation_mock/dynamo_manager.py --table $TABLE_NAME \
                                --index $AWS_BATCH_JOB_ARRAY_INDEX --batchid $BATCH_ID
                            
                            /fsx/...raw.../input.bag
                            /bucket2/<directory>/outpuut.json
                            
                            echo $(find /tmp/ -type f -name "*.bag")
                            
                            python simulation_mock/processing.py --tablename $TABLE_NAME \
                                --s3bucketout $TARGET_BUCKET \
                                --index $AWS_BATCH_JOB_ARRAY_INDEX --batchid $BATCH_ID
                            
                            """
                    ),
                ],
                "environment": [
                    {"name": "BATCH_ID", "value": batch_id},
                    {"name": "TABLE_NAME", "value": batch_dag_config.DYNAMODB_TABLE},
                    {"name": "JOB_NAME", "value": batch_id},
                    {"name": "DEBUG", "value": "true"},
                    {"name": "AWS_ACCOUNT_ID", "value": boto3.client('sts').get_caller_identity().get('Account')},
                    {"name": "TARGET_BUCKET", "value": batch_dag_config.TARGET_BUCKET},
                ],
            },
        )

        op.execute(ds)


    submit_batch_job = PythonOperator(task_id='submit_batch_job', python_callable=my_func)

    deregister_batch_job_defintion = PythonOperator(
        task_id="deregister_batch_job_defintion",
        dag=dag,
        provide_context=True,
        op_kwargs={
            # "job_def_arn": "{{ task_instance.xcom_pull(task_ids='deregister_batch_job_defintion', key='job_definition_arn') }}"
            "job_def_arn": batch_dag_config.JOB_CONFIGS[PROVIDER]["JOB_DEF_NAME"]
        },
        python_callable=deregister_job_definition,
    )

    # s3_to_redshift = S3ToRedshiftOperator(
    #     task_id='s3_to_redshift',
    #     schema='fct',
    #     table='from_redshift',
    #     s3_bucket='airflow-redshift-demo',
    #     s3_key='fct/from_redshift',
    #     redshift_conn_id='redshift_default',
    #     aws_conn_id='aws_default',
    #     copy_options=[
    #         "DELIMITER AS ','"
    #     ],
    #     method='REPLACE'
    # )

    create_aws_conn >> create_batch_of_drives_task >> register_batch_job_defintion >> submit_batch_job >> deregister_batch_job_defintion
