#  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License").
#    You may not use this file except in compliance with the License.
#    You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.

#  This file is populated with configurations information when the Module is deployed
#  Configuration parameters are exported as module level constants
#
#  Example:
#  SOME_PARAMETER = 'some value'
DAG_ROLE = "arn:aws:iam::029311181571:role/addl-arriver-poc2-poc2-batch-dag-dag-role"

PROVIDER = "SPOT"

JOB_CONFIGS = {
    "EC2": {
        "JOB_DEF_NAME": "addl-arriver-poc2-poc2-batch-dag-simplemock-ec2-jobdef",
        "JOB_QUEUE_ARN": "addl-arriver-poc2-poc2-batch-dag-OnDemandJobQueue"
    },
    "FARGATE": {
        "JOB_DEF_NAME": "addl-arriver-poc2-poc2-batch-dag-simplemock-fargate-jobdef",
        "JOB_QUEUE_ARN": "addl-arriver-poc2-poc2-batch-dag-FargateJobQueue"
    },
    "SPOT": {
        "JOB_DEF_NAME": "addl-arriver-poc2-poc2-batch-dag-simplemock-spot-jobdef",
        "JOB_QUEUE_ARN": "addl-arriver-poc2-poc2-batch-dag-SpotJobQueue"
    },
}

DYNAMODB_TABLE = "addl-arriver-poc2-poc2-batch-dag-tracking-drives"
SRC_BUCKET = "addl-arriver-raw-bucket-444e5acb"
TARGET_BUCKET = "addl-arriver-intermediate-bucket-444e5acb"
MAX_NUM_SEGMENTS_PER_BATCH = 8000
SEGMENT_SUFFIX = ".bag"
ECR_REPO_NAME = "addl-arriver-poc2-poc2-batch-dag"
REGION = "eu-central-1"
VCPU = "4"
MEMORY = "16384"
CONTAINER_TIMEOUT = 60 # Seconds - must be at least 60 seconds
