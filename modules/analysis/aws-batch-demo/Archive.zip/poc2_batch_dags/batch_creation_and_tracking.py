#  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License").
#    You may not use this file except in compliance with the License.
#    You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.

import boto3
from boto3.dynamodb.conditions import Key
s3_client = boto3.client('s3')


def add_drives_to_batch(
        table, src_bucket, max_segments_per_batch,
        batch_id, segments_in_batch, next_continuation,
        segment_suffix
    ):
    drives_and_segments = {}
    drive_id_batch, drive_continuation = get_batch_of_drive_ids(src_bucket, next_continuation=next_continuation)

    for drive_id in drive_id_batch:
        if drive_id_exists(table, drive_id):
            continue
        segments = get_drive_segments(drive_id, src_bucket, segment_suffix)

        if segments_in_batch + len(segments) > max_segments_per_batch:
            print(f"Adding this drive with {len(segments)} segments would exceed the batch size threshold")
            next_continuation = None
            break

        drives_and_segments[drive_id] = segments
        segments_in_batch += len(segments)

    batch_write_segments_to_dynamo(table, drives_and_segments, src_bucket, batch_id)
    return segments_in_batch, next_continuation


def get_batch_of_drive_ids(src_bucket, next_continuation=None):
    MAX_KEYS = 1000

    if next_continuation:
        response = s3_client.list_objects_v2(
            Bucket=src_bucket,
            MaxKeys=MAX_KEYS,
            Delimiter='/',
            ContinuationToken=next_continuation
        )
    else:
        response = s3_client.list_objects_v2(Bucket=src_bucket, MaxKeys=MAX_KEYS, Delimiter='/')

    drive_ids = [x['Prefix'][0:-1] for x in response.get('CommonPrefixes', [])]
    next_continuation = response.get('NextContinuationToken')
    return drive_ids, next_continuation


def get_drive_segments(drive_id, src_bucket, segment_suffix):
    MAX_KEYS = 1000
    segment_response = s3_client.list_objects_v2(Bucket=src_bucket, Prefix=drive_id + "/", MaxKeys=MAX_KEYS,
                                                 Delimiter='/')
    segment_next_continuation = segment_response.get('NextContinuationToken')
    segments = [x['Key'] for x in segment_response.get("Contents", []) if x['Key'].endswith(segment_suffix)]
    while segment_next_continuation is not None:
        segment_response = s3_client.list_objects_v2(
            Bucket=src_bucket,
            Prefix=drive_id + "/",
            MaxKeys=MAX_KEYS,
            Delimiter='/',
            ContinuationToken=segment_next_continuation
        )
        segment_next_continuation = segment_response.get('NextContinuationToken')
        segments += [x['Key'] for x in segment_response.get("Contents", [])]

    return segments


def drive_id_exists(table, drive_id):
    cnt = table.query(
        KeyConditionExpression=Key('drive_id').eq(drive_id),
        Select='COUNT',
    )['Count']
    return cnt > 0


def batch_write_segments_to_dynamo(table, drives_and_segments, src_bucket, batch_id):

    with table.batch_writer() as batch:
        idx = 0
        for drive_id, segments in drives_and_segments.items():
            for segment in segments:
                batch.put_item(
                    Item={
                        'drive_id': drive_id,
                        'segment_id': segment.replace(drive_id, '').replace("/", ''),
                        's3_bucket': src_bucket,
                        's3_key': segment,
                        'batch_id': batch_id,
                        'array_index_id': idx
                    }
                )
                idx += 1
