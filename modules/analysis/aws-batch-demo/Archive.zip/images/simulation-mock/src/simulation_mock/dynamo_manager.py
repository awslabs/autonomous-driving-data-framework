#  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License").
#    You may not use this file except in compliance with the License.
#    You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.

import argparse
import json
import sys

from simulation_mock import get_logger
import boto3
from boto3.dynamodb.conditions import Key

LOGGER = get_logger()


def main(table_name, index, batch_id) -> int:
    LOGGER.info("table: %s", table_name)
    LOGGER.info("index: %s", index)
    LOGGER.info("batch_id: %s", batch_id)

    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(table_name)

    response = table.query(
        IndexName='batch_file_lookup',
        Select='ALL_ATTRIBUTES',
        KeyConditionExpression=Key('batch_id').eq(batch_id) & Key('array_index_id').eq(int(index))
    )['Items']
    try:
        assert len(response) == 1, f"expected 1 item to be returned, received {response}"
    except AssertionError:
        return 1

    item = response[0]
    item["array_index_id"] = int(item["array_index_id"])

    with open('/tmp/dynamo_item.json', 'w') as fp:
        json.dump(item, fp)

    s3 = boto3.client('s3')
    s3.download_file(item['s3_bucket'], item['s3_key'], f"/tmp/input.bag")

    LOGGER.info(response)
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Manage Dynamo Tracking")
    parser.add_argument("--table", required=True)
    parser.add_argument("--index", required=True)
    parser.add_argument("--batchid", required=True)
    args = parser.parse_args()

    LOGGER.debug("ARGS: %s", args)
    sys.exit(main(table_name=args.table, index=args.index, batch_id=args.batchid))
