#  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License").
#    You may not use this file except in compliance with the License.
#    You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.

import argparse
import json
import sys

from simulation_mock import get_logger
import boto3
from boto3.dynamodb.conditions import Key

LOGGER = get_logger()


def main(table_name, index, batch_id, s3bucketout) -> int:
    LOGGER.info("s3bucketout: %s", s3bucketout)
    LOGGER.info("batch_id: %s", batch_id)
    LOGGER.info("index: %s", index)
    LOGGER.info("table_name: %s", table_name)

    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(table_name)

    response = table.query(
        IndexName='batch_file_lookup',
        Select='ALL_ATTRIBUTES',
        KeyConditionExpression=Key('batch_id').eq(batch_id) & Key('array_index_id').eq(int(index))
    )['Items']
    try:
        assert len(response) == 1, f"expected 1 item to be returned, received {response}"
    except AssertionError:
        return 1

    item = response[0]
    driveid = item['drive_id']
    segmentid = item['segment_id']
    output_key = item['s3_key'].replace(".bag", ".json")

    with open(f'/tmp/input.bag', 'r') as f:
        try:
            data = json.load(f)
        except:
            data = {"data": "na"}

    with open(f'/tmp/output.json', 'w') as f:
        json.dump(data, f)

    s3 = boto3.client('s3')
    with open("/tmp/output.json", "rb") as f:
        s3.upload_fileobj(f, s3bucketout, output_key)

    table.update_item(
        Key={
            'drive_id': driveid,
            'segment_id': segmentid
        },
        UpdateExpression=f"SET job_status = :status, output_key = :output_key, output_bucket = :output_bucket",
        ExpressionAttributeValues={
            ":status": "success",
            ":output_key": output_key,
            ":output_bucket": s3bucketout
        },
    )

    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process Files")
    parser.add_argument("--s3bucketout", required=True)
    parser.add_argument("--batchid", required=True)
    parser.add_argument("--index", required=True)
    parser.add_argument("--tablename", required=True)

    args = parser.parse_args()

    LOGGER.debug("ARGS: %s", args)
    sys.exit(
        main(
            s3bucketout=args.s3bucketout,
            batch_id=args.batchid,
            index=args.index,
            table_name=args.tablename,
        )
    )
